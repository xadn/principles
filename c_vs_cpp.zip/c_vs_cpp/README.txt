C vs C++

By Andy Niccolai for Principles of Programming Languages at the Colorado 
School of Mines on 4/11/2011

Description of Files:

c_vs_cpp.html is a static webpage describing 5 differences between C and
C++. It should be viewable by any modern web browser.

c_vs_cpp.css is a dependency of c_vs_cpp.html.